import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseInterceptors,
  UploadedFile,
  ParseIntPipe,
  HttpStatus,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import {
  ApiTags,
  ApiOperation,
  ApiResponse,
  ApiParam,
  ApiQuery,
  ApiConsumes,
  ApiBody,
} from '@nestjs/swagger';
import { ContentsService } from './contents.service';
import { CreateContentDto } from './dto/create-content.dto';
import { UpdateContentDto } from './dto/update-content.dto';
import {
  ContentResponseDto,
  PaginatedContentResponseDto,
} from './dto/content-response.dto';
import { multerConfig } from '../common/multer.config';

@ApiTags('contents')
@Controller('contents')
export class ContentsController {
  constructor(private readonly contentsService: ContentsService) {}

  @Get()
  @ApiOperation({ summary: 'コンテンツ一覧取得' })
  @ApiQuery({
    name: 'page',
    required: false,
    type: Number,
    description: 'ページ番号（デフォルト: 1）',
  })
  @ApiQuery({
    name: 'limit',
    required: false,
    type: Number,
    description: '1ページあたりの件数（デフォルト: 20）',
  })
  @ApiQuery({
    name: 'type',
    required: false,
    enum: ['image', 'video'],
    description: '種別フィルタ',
  })
  @ApiQuery({
    name: 'keyword',
    required: false,
    type: String,
    description: '検索キーワード（タイトル・説明文）',
  })
  @ApiQuery({
    name: 'tag',
    required: false,
    type: String,
    description: 'タグフィルタ',
  })
  @ApiResponse({
    status: 200,
    description: 'コンテンツ一覧を返却',
    type: PaginatedContentResponseDto,
  })
  async findAll(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
    @Query('type') type?: string,
    @Query('keyword') keyword?: string,
    @Query('tag') tag?: string,
  ) {
    return this.contentsService.findAll(
      page || 1,
      limit || 20,
      type,
      keyword,
      tag,
    );
  }

  @Get(':id')
  @ApiOperation({ summary: 'コンテンツ詳細取得' })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'コンテンツID',
  })
  @ApiResponse({
    status: 200,
    description: 'コンテンツ詳細を返却',
    type: ContentResponseDto,
  })
  @ApiResponse({
    status: 404,
    description: 'コンテンツが見つかりません',
  })
  async findOne(@Param('id', ParseIntPipe) id: number) {
    return this.contentsService.findOne(id);
  }

  @Post()
  @ApiOperation({ summary: 'コンテンツ登録' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'コンテンツ登録データ',
    type: CreateContentDto,
  })
  @ApiResponse({
    status: 201,
    description: 'コンテンツを登録しました',
    type: ContentResponseDto,
  })
  @ApiResponse({
    status: 400,
    description: '不正なリクエスト',
  })
  @UseInterceptors(FileInterceptor('file', multerConfig))
  async create(
    @Body() createContentDto: CreateContentDto,
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.contentsService.create(createContentDto, file);
  }

  @Put(':id')
  @ApiOperation({ summary: 'コンテンツ更新' })
  @ApiConsumes('multipart/form-data')
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'コンテンツID',
  })
  @ApiBody({
    description: 'コンテンツ更新データ',
    type: UpdateContentDto,
  })
  @ApiResponse({
    status: 200,
    description: 'コンテンツを更新しました',
    type: ContentResponseDto,
  })
  @ApiResponse({
    status: 404,
    description: 'コンテンツが見つかりません',
  })
  @UseInterceptors(FileInterceptor('file', multerConfig))
  async update(
    @Param('id', ParseIntPipe) id: number,
    @Body() updateContentDto: UpdateContentDto,
    @UploadedFile() file?: Express.Multer.File,
  ) {
    return this.contentsService.update(id, updateContentDto, file);
  }

  @Delete(':id')
  @ApiOperation({ summary: 'コンテンツ削除' })
  @ApiParam({
    name: 'id',
    type: Number,
    description: 'コンテンツID',
  })
  @ApiResponse({
    status: 200,
    description: 'コンテンツを削除しました',
    schema: {
      type: 'object',
      properties: {
        status: { type: 'string', example: 'deleted' },
      },
    },
  })
  @ApiResponse({
    status: 404,
    description: 'コンテンツが見つかりません',
  })
  async remove(@Param('id', ParseIntPipe) id: number) {
    await this.contentsService.remove(id);
    return { status: 'deleted' };
  }
}
