import { ApiProperty } from '@nestjs/swagger';
import { IsString, IsNotEmpty, IsIn, IsOptional, IsBoolean, IsArray, MaxLength } from 'class-validator';

export class CreateContentDto {
  @ApiProperty({
    description: 'コンテンツのタイトル',
    example: '新入社員研修ビデオ',
    maxLength: 200,
  })
  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  title: string;

  @ApiProperty({
    description: 'コンテンツの説明（Markdown対応）',
    example: '2025年度新入社員向けの会社概要と業務フローの説明動画です。',
  })
  @IsString()
  @IsNotEmpty()
  description: string;

  @ApiProperty({
    description: 'コンテンツの種別',
    enum: ['image', 'video'],
    example: 'video',
  })
  @IsIn(['image', 'video'])
  type: 'image' | 'video';

  @ApiProperty({
    description: 'ファイル',
    type: 'string',
    format: 'binary',
  })
  file: any;

  @ApiProperty({
    description: '公開状態',
    example: true,
    required: false,
  })
  @IsOptional()
  @IsBoolean()
  isPublic?: boolean;

  @ApiProperty({
    description: 'タグ（配列）',
    example: ['新入社員', '研修', '必須'],
    required: false,
    type: [String],
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];
}
